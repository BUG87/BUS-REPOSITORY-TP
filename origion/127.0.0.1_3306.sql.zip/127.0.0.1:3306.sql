-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- 主机: 127.0.0.1:3306
-- 生成日期: 2015 年 08 月 05 日 06:23
-- 服务器版本: 5.1.28
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `b1506`
--
CREATE DATABASE `b1506` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `b1506`;

-- --------------------------------------------------------

--
-- 表的结构 `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `mem_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mem_name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `mem_qq` varchar(64) CHARACTER SET utf8 NOT NULL,
  `is_in` varchar(1) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`mem_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- 导出表中的数据 `member`
--

INSERT INTO `member` (`mem_id`, `mem_name`, `mem_qq`, `is_in`) VALUES
(1, '陈兰', '2090378502', '1'),
(2, '叶维', '1244403025', '1'),
(3, '胡健', '703608915', '1'),
(4, '刘汉滨', '625796620', '1'),
(5, '曾红彬', '1375683785', '1'),
(6, '易嘉杰', '459337607', ''),
(7, '李海洋', '1372171977', '1'),
(8, '叶广俊', '1255115350', ''),
(9, '曾炜生', '646154866', ''),
(10, '黄茂恩', '825846218', ''),
(11, '郭纳弟', '707952345', '1'),
(12, '刘福年', '837317148', '1'),
(13, '吕飞鹏', '305984128', ''),
(14, '赖文静', '554980850', '1'),
(15, '魏威', '275071168', '1'),
(16, '李子奇', '992326147', '1'),
(17, '曹球亮', '1711304830', '1'),
(18, '陈英', '405872788', '1'),
(19, '宁上康', '894606300', ''),
(20, '黎贵平', '1259163451', '1'),
(21, '黄文', '942741914', '1'),
(22, '周松', '520290361', ''),
(23, '黄蓉', '173889132', ''),
(24, '陈浩贤', '81417743', ''),
(25, '周杰雄', '782689355', ''),
(26, '周诚锋', '47638298', ''),
(27, '陈凤森', '594923603', ''),
(28, '冯道俊', '492989187', '1'),
(29, '关国亮', '307623876', ''),
(30, '陈真泉', '', ''),
(31, '卢省明', '401030722', '1'),
(32, '蔡金黄', '897753930', '1'),
(33, '李海龙', '', ''),
(35, '房鑫鑫', '569550746', '');
